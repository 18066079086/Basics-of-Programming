#include "Canvas.h"

#include <thread>
#include <chrono>
#include <iostream>
#include <algorithm>

#ifdef ENABLE_UNICODE_OUTPUT
/**
 * @brief Convert a half-width character to a full-width character.
 * @param ch a half-width character
 * @return the full-width character corresponding
 */
wchar_t ToFullWidth(wchar_t ch) {
    if (ch == 0x20)
        return 0x3000;

    if (ch > 0x20 && ch < 0x7f)
        return 0xff00 + ch - 0x20;

    return 0x3000;
}
#endif

void Wait(uint milliseconds) {
    std::this_thread::sleep_for(std::chrono::milliseconds(milliseconds));
}

Rect::Rect(int z) : z(z) {}

Rect::Rect(uint row, uint col, uint height, uint width, int fontColor, int backgroundColor, int z,
#ifdef ENABLE_UNICODE_OUTPUT
const std::wstring& text, wchar_t fill
#else
const std::string& text, char fill
#endif
):
row(row), col(col), height(height), width(width), fontColor(fontColor), backgroundColor(backgroundColor), z(z), text(text), fill(fill) {}

InputManager::InputManager() : keyDown{false}, lastVirtualKeyPressed{VK_NOTHING} {
    if (!LoadConsole()) {
        std::cerr << "Failed to load console's Standard Input." << std::endl;
    }
}

bool InputManager::UpdateInput() {
    if (consoleInputHandle == INVALID_HANDLE_VALUE) {
        std::cerr << "Incorrect console input handle." << std::endl;
        return false;
    }

    lastVirtualKeyPressed = VK_NOTHING;

    DWORD ret;
    if (!GetNumberOfConsoleInputEvents(consoleInputHandle, &ret)) {
        std::cerr << "Cannot get the number of input events." << std::endl;
        return false;
    }

    if (ret > MAX_INPUT_EVENTS) {
        std::cerr << "Too many input events." << std::endl;
        return false;
    }

    if (ret > 0) {
        INPUT_RECORD inputEvent[MAX_INPUT_EVENTS];
        DWORD ret_aux;
        ReadConsoleInput(consoleInputHandle, inputEvent, ret, &ret_aux);
        for (uint i = 0; i < ret_aux; i++) {
            switch (inputEvent[i].EventType) {
                case KEY_EVENT: {
                    KEY_EVENT_RECORD& event = inputEvent[i].Event.KeyEvent;
                    if (!event.bKeyDown && keyDown[event.wVirtualKeyCode]) {
                        lastVirtualKeyPressed = event.wVirtualKeyCode;
                    }
                    keyDown[event.wVirtualKeyCode] = event.bKeyDown;
                    break;
                }
                case MOUSE_EVENT:
                case WINDOW_BUFFER_SIZE_EVENT:
                case FOCUS_EVENT:
                case MENU_EVENT:
                default:
                    break;
            }
        }
    }

    return true;
}

ushort InputManager::GetLastKeyPressed() const {
    return lastVirtualKeyPressed;
}

bool InputManager::LoadConsole() {
    consoleInputHandle = INVALID_HANDLE_VALUE;
    consoleInputHandle = GetStdHandle(STD_INPUT_HANDLE);
    if (consoleInputHandle == INVALID_HANDLE_VALUE) {
        std::cerr << "Incorrect console input handle." << std::endl;
        return false;
    }
    return true;
}

bool InputManager::IsValid() const {
    if (consoleInputHandle == INVALID_HANDLE_VALUE) {
        return false;
    }

    return true;
}

OutputManager::OutputManager(CHAR_INFO defaultCharInfo, uint rows, uint cols) {
    if (!LoadConsole(defaultCharInfo, rows, cols)) {
        std::cerr << "Failed to load console's Standard Output." << std::endl;
    }
}

void OutputManager::Output(uint row, uint col, uint height, uint width, const std::vector<CHAR_INFO>& content) {
    for (uint i = 0; i < height; ++i)
        for (uint j = 0; j < width; ++j) {
            if (row + i >= rows || col + j >= cols) /// outside the canvas
                continue;

            CHAR_INFO current = content[i * width + j];

#ifdef ENABLE_UNICODE_OUTPUT
            /// convert the half-width character to the full-width character
            if (current.Char.UnicodeChar < 0x80)
                current.Char.UnicodeChar = ToFullWidth(current.Char.UnicodeChar);
#endif

            /// when the background color is transparent
            if (current.Attributes & C_TRANSPARENT << 4) {
                current.Attributes |= buffer[(row + i) * cols + col + j].Attributes & 0xf0;
                current.Attributes &= 0xfff;
            }

            /// when the font color is transparent
            if (current.Attributes & C_TRANSPARENT) {
                current.Attributes |= (current.Attributes & 0xf0) >> 4;
                current.Attributes &= 0xff;
            }

            buffer[(row + i) * cols + col + j] = current;
        }
}

// void OutputManager::Fill(uint row, uint col, uint height, uint width, CHAR_INFO charInfo) {
// #ifdef ENABLE_UNICODE_OUTPUT
//     if (charInfo.Char.UnicodeChar < 0x80)
//         charInfo.Char.UnicodeChar = ToFullWidth(charInfo.Char.UnicodeChar);
// #endif
//     for (int i = 0; i < height && i < rows - row; ++i)
//         for (int j = 0; j < width && j < cols - col; ++j) {
//             buffer[(row + i) * cols + col + j] = charInfo;
//         }
// }

void OutputManager::Fill(CHAR_INFO charInfo) {
#ifdef ENABLE_UNICODE_OUTPUT
    if (charInfo.Char.UnicodeChar < 0x80)
        charInfo.Char.UnicodeChar = ToFullWidth(charInfo.Char.UnicodeChar);
#endif
    std::fill(buffer.begin(), buffer.end(), charInfo);
}

void OutputManager::SetCursorPosition(uint row, uint col) const {
    if (row >= rows || col >= cols)
        return;

    COORD coord = {(short)col, (short)row};
    SetConsoleCursorPosition(consoleOutputHandle, coord);
}

void OutputManager::SetCursorVisible(bool visible) const {
    CONSOLE_CURSOR_INFO info;
    info.bVisible = visible;
    info.dwSize = 1;
    SetConsoleCursorInfo(consoleOutputHandle, &info);
}

bool OutputManager::UpdateOutput() const {
    COORD origin = {0, 0};
    COORD size = {(short)cols, (short)rows};
    SMALL_RECT rect = {0, 0, (short)(cols - 1), (short)(rows - 1)};

    if (!WriteConsoleOutput(consoleOutputHandle, &buffer[0], size, origin, &rect)) {
        std::cerr << "Failed to write to console output." << std::endl;
        return false;
    }
    return true;
};

uint OutputManager::GetMaxRows() const {
    return rows;
}

uint OutputManager::GetMaxCols() const {
    return cols;
}

bool OutputManager::LoadConsole(CHAR_INFO defaultCharInfo, uint rows, uint cols) {
    consoleOutputHandle = INVALID_HANDLE_VALUE;
    consoleOutputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    if (consoleOutputHandle == INVALID_HANDLE_VALUE) {
        std::cerr << "Incorrect console output handle." << std::endl;
        return false;
    }

    CONSOLE_SCREEN_BUFFER_INFO info;
    if (!GetConsoleScreenBufferInfo(consoleOutputHandle, &info)) {
        std::cerr << "Cannot load console info." << std::endl;
        return false;
    }

    // this->rows = info.dwSize.X;
    // this->cols = info.dwSize.Y;

    this->rows = rows < info.dwSize.Y ? rows : info.dwSize.Y;
#ifdef ENABLE_UNICODE_OUTPUT
    this->cols = cols < info.dwSize.X / 2 ? cols : info.dwSize.X / 2;
#else
    this->cols = cols < info.dwSize.X ? cols : info.dwSize.X;
#endif
    size = this->rows * this->cols;

    buffer = std::vector<CHAR_INFO>(size, defaultCharInfo);

    return true;
}

bool OutputManager::IsValid() const {
    if (consoleOutputHandle == INVALID_HANDLE_VALUE) {
        return false;
    }

    if (buffer.empty()) {
        return false;
    }

    return true;
}

/**
 * Rect with lower layer level 'z' should be drawn first.
 */
bool CompareRectPointer(Rect* left, Rect* right) {
    if (left->z == right->z)
        return left < right;
    return left->z < right->z;
}

Canvas::Canvas(uint rows, uint cols) : outputManager(DefaultCharInfo(), rows, cols), rectangles(CompareRectPointer) {
    if (!inputManager.IsValid() || !outputManager.IsValid()) {
        std::cerr << "Incorrect console initialization." << std::endl;
    }
}

void Canvas::AddObject(Rect *rect) {
    rectangles.insert(rect);
}

void Canvas::AddObjects(const std::vector<Rect*>& rects) {
    for (Rect* rect : rects) {
        rectangles.insert(rect);
    }
}

void Canvas::RemoveObject(Rect *rect) {
    rectangles.erase(rect);
}

void Canvas::RemoveObjects(const std::vector<Rect*>& rects) {
    for (Rect* rect : rects) {
        rectangles.erase(rect);
    }
}

void Canvas::RemoveAllObjects() {
    rectangles.clear();
}

void Canvas::SetCursorPosition(uint row, uint col) const {
    outputManager.SetCursorPosition(row, col);
}

void Canvas::SetCursorVisible(bool visible) const {
    outputManager.SetCursorVisible(visible);
}

bool Canvas::UpdateInput() {
    return inputManager.UpdateInput();
}

ushort Canvas::GetLastKeyPressed() const {
    return inputManager.GetLastKeyPressed();
}

void Canvas::DrawGroup(int z) {
    DrawGroup(z, z);
}

void Canvas::DrawGroup(int lowerZ, int higherZ) {
    // std::sort(rectangles.begin(), rectangles.end(), CompareRectPointer);
    for (Rect* rect : rectangles) {
        if (rect->z < lowerZ)
            continue;
        if (rect->z > higherZ)
            break;
        ForceDrawObject(rect);
    }
}

void Canvas::DrawAll() {
    // std::sort(rectangles.begin(), rectangles.end(), CompareRectPointer);
    for (Rect* rect : rectangles) {
        ForceDrawObject(rect);
    }
}

void Canvas::Clean() {
    outputManager.Fill(DefaultCharInfo());
}

void Canvas::UpdateOutput(bool force) const {
    if (force)
        while (!outputManager.UpdateOutput()) {
            Wait(FRAME_MILLISECONDS);
        }
    else
        outputManager.UpdateOutput();
}

uint Canvas::GetMaxRows() const {
    return outputManager.GetMaxRows();
}

uint Canvas::GetMaxCols() const {
    return outputManager.GetMaxCols();
}

void Canvas::SetDefaultFontColor(int foregroundColor) {
    if (foregroundColor == C_TRANSPARENT)
        return;
    this->defaultFontColor = foregroundColor;
}

void Canvas::SetDefaultBackgroundColor(int backgroundColor) {
    if (backgroundColor == C_TRANSPARENT)
        return;
    this->defaultBackgroundColor = backgroundColor;
}

#ifdef ENABLE_UNICODE_OUTPUT
void Canvas::SetDefaultFill(wchar_t fill) {
    this->defaultFill = fill;
}
#else
void Canvas::SetDefaultFill(char fill) {
    this->defaultFill = fill;
}
#endif

void Canvas::ForceDrawObject(Rect *rect) {
    CHAR_INFO fill;
    fill.Attributes = rect->fontColor | rect->backgroundColor << 4;
#ifdef ENABLE_UNICODE_OUTPUT
    fill.Char.UnicodeChar = rect->fill;
#else
    fill.Char.AsciiChar = rect->fill;
#endif

    std::vector<CHAR_INFO> content(rect->height * rect->width, fill);

    /// from left to right, from top to bottom
    /// If you want more alignment modes, you can make some changes here.
    for (uint i = 0; i < content.size() && i < rect->text.size(); ++i) {
#ifdef ENABLE_UNICODE_OUTPUT
        content[i].Char.UnicodeChar = rect->text[i];
#else
        texture[i].Char.AsciiChar = rect->text[i];
#endif
    }

    outputManager.Output(rect->row, rect->col, rect->height, rect->width, content);
}

CHAR_INFO Canvas::DefaultCharInfo() const {
    CHAR_INFO defaultCharInfo;
    defaultCharInfo.Attributes = defaultFontColor | defaultBackgroundColor << 4;
#ifdef ENABLE_UNICODE_OUTPUT
    defaultCharInfo.Char.UnicodeChar = defaultFill;
#else
    defaultCharInfo.Char.AsciiChar = defaultFill;
#endif
    return defaultCharInfo;
}
