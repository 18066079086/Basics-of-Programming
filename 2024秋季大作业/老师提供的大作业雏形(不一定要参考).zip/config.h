#ifndef CONFIG_H
#define CONFIG_H

#define MAP_SIZE 8

enum MapElement {
    GROUND      = 0,
    WALL        = 1,
    LAVA        = 2,
    HERO        = 3,
    DOOR        = 4,
    UP_STAIRS   = 5,
    DOWN_STAIRS = 6,
};

constexpr int INITIAL_MAP[MAP_SIZE][MAP_SIZE] = {
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 0, 0, 3, 0, 0, 0, 1,
    1, 2, 2, 0, 0, 2, 2, 1,
    1, 2, 2, 0, 0, 2, 2, 1,
    1, 0, 0, 2, 2, 0, 0, 1,
    1, 0, 2, 2, 2, 2, 0, 1,
    1, 0, 2, 0, 0, 2, 0, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
};

#define HERO_HP  10
#define HERO_ATK 20
#define HERO_DEF 30


#endif //CONFIG_H
