#ifndef CANVAS_H
#define CANVAS_H

/** Add Chinese language support  */
#define ENABLE_UNICODE_OUTPUT

#include <windows.h>

#include <set>
#include <vector>
#include <string>

#include "constants.h"

#undef VK_UP
#undef VK_DOWN
#undef VK_LEFT
#undef VK_RIGHT

#define MAX_INPUT_EVENTS 100

#define FRAME_MILLISECONDS 10

// default setting (perhaps?)
#define MAX_ROWS 30
#define MAX_COLS 120

#define DEFAULT_ROWS MAX_ROWS

#ifdef ENABLE_UNICODE_OUTPUT
#define DEFAULT_COLS (MAX_COLS / 2)
#else
#define DEFAULT_COLS MAX_COLS
#endif

using uint = unsigned int;
using ushort = unsigned short;

/**
 * @brief Block all operations for a period of time.
 */
void Wait(uint milliseconds);

/**
 * @brief Rect is used to describe a rectangular area to be drawn on the canvas.
 */
struct Rect {
    uint row = 0; /// top row of the rectangular area
    uint col = 0; /// left column of the rectangular area

    uint height = 0; /// row height of the rectangular area
    uint width = 0; /// column width of the rectangular area

    int fontColor = C_WHITE; /// font color of every character in the rectangular area
    int backgroundColor = C_BLACK; /// background color of the rectangular area

    const int z = 0; /// layer level of the rectangular area. In the same position, rectangular area with higher layer levels will overlap those with lower layer levels.

#ifdef ENABLE_UNICODE_OUTPUT
    std::wstring text; /// text contained in the rectangular area (from left to right, top to bottom)
    wchar_t fill = 0x3000; /// default fill character in the rectangular area
#else
    std::string text; /// text contained within the rectangular area (from left to right, top to bottom)
    char fill = ' '; /// default fill character in the rectangular area
#endif

    /**
     * @brief constructor that only initializes the layer level 'z', with other variables assigned default values.
     * @param z layer level of the rectangular area
     */
    explicit Rect(int z = 0);

    /**
     * @brief complete constructor that initializes all the variables
     * @param row top row of the rectangular area
     * @param col left column of the rectangular area
     * @param height row height of the rectangular area
     * @param width column width of the rectangular area
     * @param fontColor font color of every character in the rectangular area
     * @param backgroundColor background color of the rectangular area
     * @param z layer level of the rectangular area
     * @param text text contained in the rectangular area (from left to right, top to bottom)
     * @param fill default fill character in the rectangular area
     */
    Rect(uint row, uint col, uint height, uint width, int fontColor, int backgroundColor, int z = 0,
#ifdef ENABLE_UNICODE_OUTPUT
    const std::wstring& text = L"", wchar_t fill = 0x3000
#else
    const std::string& text = "", char fill = ' '
#endif
    );

    /**
     * @brief copy constructor that initializes all variables to be the same as another rectangular area
     * @param other another rectangular area
     */
    Rect(const Rect& other) = default;
};

/**
 * @brief the InputManager is used to process the console input
 */
class InputManager {
public:
    InputManager();

    /**
     * @brief Read input events and store the last key pressed.
     * @return whether the operation is successful
     */
    bool UpdateInput();

    /**
     * @brief get the last key pressed
     * @return the last key pressed
     */
    ushort GetLastKeyPressed() const;

    /**
     * @brief Check whether the InputManager has been properly initialized.
     * @return whether the InputManager has been properly initialized
     */
    bool IsValid() const;

private:
    HANDLE consoleInputHandle; /// pointer to the Standard Input

    bool keyDown[65536]; /// whether a key is down (key pressed = key down + key up)

    ushort lastVirtualKeyPressed; /// the last key pressed

private:
    /**
     * @brief Initialize the InputManager with Standard Input.
     */
    bool LoadConsole();
};

/**
 * @brief the OutputManager is used to process the console output
 */
class OutputManager {
public:
    /**
     * @brief create a canvas
     * @param defaultCharInfo default fill content
     * @param rows number of rows contained in the canvas
     * @param cols number of columns contained in the canvas
     */
    OutputManager(CHAR_INFO defaultCharInfo, uint rows, uint cols);

    /**
     * @brief Draw a rectangular area in the canvas.
     */
    void Output(uint row, uint col, uint rows, uint cols, const std::vector<CHAR_INFO>& content);

    //void Fill(uint row, uint col, uint rows, uint cols, CHAR_INFO charInfo);

    /**
     * @brief fill the entire canvas with default content
     * @param charInfo the default content
     */
    void Fill(CHAR_INFO charInfo);

    /**
    * @brief Set the position of the cursor.
    * @param row row
    * @param col column
    */
    void SetCursorPosition(uint row, uint col) const;

    /**
    * @brief Set the visibility of the cursor.
    * @param visible cursor's visibility
    */
    void SetCursorVisible(bool visible) const;

    /**
    * @brief Output the canvas' content to the console.
    * @return whether the output operation is successful
    */
    bool UpdateOutput() const;

    /**
    * @brief Get the row height of the canvas
    * @return the row height of the canvas
     */
    uint GetMaxRows() const;
    /**
     * @brief Get the column width of the canvas
     * @return the column width of the canvas
     */
    uint GetMaxCols() const;

    /**
    * @brief Check if the OutputManager has been properly initialized.
    * @return whether the OutputManager has been properly initialized
    */
    bool IsValid() const;

private:
    HANDLE consoleOutputHandle; /// pointer to the Standard Output

    uint rows; /// number of rows contained in the canvas
    uint cols; /// number of columns contained in the canvas
    uint size; /// size of the canvas (size = rows * cols)

    std::vector<CHAR_INFO> buffer; /// buffer that stores all content to be output to console

private:
    /**
     * @brief Initialize the OutputManager with Standard Output.
     */
    bool LoadConsole(CHAR_INFO defaultCharInfo, uint rows, uint cols);
};

/**
 * @brief You can draw some rectangular areas in the canvas, instead of directly output to console. And you can also process some console input with the canvas.
 */
class Canvas {
public:
    /**
     * @brief create a canvas with specified rows and columns
     * @param rows canvas' row height
     * @param cols canvas' column width
     */
    explicit Canvas(uint rows = DEFAULT_ROWS, uint cols = DEFAULT_COLS);

    /**
     * @brief add a rectangular area to be drawn on the canvas
     * @param rect a rectangular area
     */
    void AddObject(Rect* rect);

    /**
     * @brief add a list of rectangular areas to be drawn on the canvas
     * @param rects a list of rectangular areas
     */
    void AddObjects(const std::vector<Rect*>& rects);

    /**
     * remove a rectangular area from the canvas
     * @param rect the rectangular area to be removed from the canvas
     */
    void RemoveObject(Rect* rect);

    /**
     * @brief remove a list of rectangular areas from the canvas
     * @param rects a list of rectangular areas to be removed from the canvas
     */
    void RemoveObjects(const std::vector<Rect*>& rects);

    /**
     * @brief remove all rectangular areas from the canvas
     */
    void RemoveAllObjects();

    /**
     * @brief Draw all the rectangular areas with the specified layer level.
     * @param z the specified layer level
     */
    void DrawGroup(int z);

    /**
     * @brief Draw all the rectangular areas from lower layer level to higher layer level.
     * @param lowerZ the specified lower layer level
     * @param higherZ the specified higher layer level
     */
    void DrawGroup(int lowerZ, int higherZ);

    /**
     * @brief Draw all the rectangular areas stored in the canvas.
     */
    void DrawAll();

    /**
     * @brief Clean the canvas with default content.
     */
    void Clean();

    /**
     * @brief Set the position of the cursor.
     * @param row row
     * @param col column
     */
    void SetCursorPosition(uint row, uint col) const;

    /**
     * @brief Set the visibility of the cursor.
     * @param visible cursor's visibility
     */
    void SetCursorVisible(bool visible) const;

    /**
     * @brief Read input events and store the last key pressed.
     * @return whether the operation is successful
     */
    bool UpdateInput();

    /**
     * @brief Get the last key pressed.
     * @return the last key pressed
     */
    ushort GetLastKeyPressed() const;

    /**
     * @brief Output the canvas' content to the console.
     * @param force retry continuously until the output is successful
     */
    void UpdateOutput(bool force = true) const;


    /**
     * @brief Get the row height of the canvas.
     * @return the row height of the canvas
     */
    uint GetMaxRows() const;

    /**
     * @brief Get the column width of the canvas.
     * @return the column width of the canvas
     */
    uint GetMaxCols() const;

    /**
     * @brief Set the default font color of the canvas.
     * @param foregroundColor font color
     */
    void SetDefaultFontColor(int foregroundColor);

    /**
     * @brief Set the default background color of the canvas.
     * @param backgroundColor background color
     */
    void SetDefaultBackgroundColor(int backgroundColor);
#ifdef ENABLE_UNICODE_OUTPUT
    /**
     * @brief Set the default fill character of the canvas.
     * @param fill fill character
     */
    void SetDefaultFill(wchar_t fill);
#else
    /**
     * @brief Set the default fill character of the canvas.
    * @param fill fill character
    */
    void SetDefaultFill(char fill);
#endif

private:
    int defaultFontColor = C_WHITE; /// default font color of the canvas
    int defaultBackgroundColor = C_BLACK; /// default background color of the canvas

#ifdef ENABLE_UNICODE_OUTPUT
    wchar_t defaultFill = 0x3000; /// default fill character of the canvas
#else
    char defaultFill = ' '; /// default fill character of the canvas
#endif

    InputManager inputManager;
    OutputManager outputManager;

    std::set<Rect*, bool(*)(Rect*, Rect*)> rectangles; /// rectangular areas to be drawn on the canvas

private:
    /**
     * @brief Draw a rectangular area on the canvas.
     * @param rect the specified rectangular area
     */
    void ForceDrawObject(Rect* rect);

    /**
     * the default content of the canvas (font color + background color + fill text)
     * @return the default content of canvas
     */
    CHAR_INFO DefaultCharInfo() const;
};


#endif //CANVAS_H
