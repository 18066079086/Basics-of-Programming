#include <iostream>
#include <assert.h>
using namespace std;

const int MAX_LEN = 100;

// 定义一个结构体表示课程
struct Course {
    char *name;
    struct Student *students;
    double average;
    int numStudents;
};

// 定义一个结构体表示学生
struct Student {
    char *name;
    double grade;
    struct Course *course;
};

Course *get_courses(int, int);

Course *find_course(Course *, int, char *);

void sort_course(Course *, int);

void sort_student(Student *, int, char [][MAX_LEN]);

int string_len(char *);

int cmp_strings(char *, char *);

void str_copy(char *, char *);

int string_equal(char *, char *);

int main() {
    // 不要动main函数
    int m, n;
    cin >> m >> n;
    Course *courses = get_courses(m, n);
    for (int i = 0; i < m; i++) {
        cout << courses[i].average << endl;
        cout << courses[i].numStudents << endl;
        for (int j = 0; j < courses[i].numStudents; j++) {
            cout << courses[i].students[j].grade;
            if (j != courses[i].numStudents - 1) {
                cout << ' ';
            }
            assert(courses[i].students[j].course == courses + i);
        }
        cout << endl;
    }
}

int string_len(char s1[]) {
    int len = 0;
    int i = 0;
    while (s1[i] != '\0') {
        len++;
        i++;
    }
    // printf("The length of %s is %d\n", s1, len);
    return len;
}

int cmp_strings(char str1[], char str2[]) {
    // 如果str1<str2返回1
    int len = min(string_len(str1), string_len(str2));
    for (int i = 0; i < len; i++) {
        if (str1[i] != str2[i]) {
            return str1[i] < str2[i];
        }
    }
    return 1;
}

int string_equal(char s1[], char s2[]) {
    if (string_len(s1) != string_len(s2)) {
        // printf("%s and %s are not equal.\n", s1, s2);
        return 0;
    }
    int len = string_len(s1);
    for (int i = 0; i < len; i++) {
        if (s1[i] != s2[i]) {
            return 0;
        }
    }
    return 1;
}

Course *find_course(Course cou[], int m, char name[]) {
    for (int i = 0; i < m; ++i) {
        if (string_equal(cou[i].name, name)) {
            return &cou[i];
        }
    }
    return NULL;
}

void sort_course(Course course[], int n) {
    for (int i = 0; i < n - 1; ++i)
        for (int j = 0; j < n - 1 - i; ++j)
            if (!cmp_strings(course[j].name, course[j + 1].name)) {
                Course temp = course[j];
                course[j] = course[j + 1];
                course[j + 1] = temp;
            }
}

void str_copy(char *dest, char *src) {
    for (int i = 0; i < MAX_LEN; ++i) { //必须是i < MAX_LEN
        dest[i] = src[i];
    }
}

void sort_student(Student student[], int n, char course_name[][MAX_LEN]) {
    for (int i = 0; i < n - 1; ++i)
        for (int j = 0; j < n - 1 - i; ++j)
            if (!cmp_strings(student[j].name, student[j + 1].name)) {
                Student temp = student[j];
                student[j] = student[j + 1];
                student[j + 1] = temp;

                char temp_str[MAX_LEN];
                str_copy(temp_str, course_name[j]);
                str_copy(course_name[j], course_name[j + 1]);
                str_copy(course_name[j + 1], temp_str);
            }
}

Course *get_courses(int m, int n) {
    Course *cou = (Course *) malloc(m * sizeof(Course));
    Student *stu = (Student *) malloc(n * sizeof(Student));

    // 输入课程基本信息，指针先不连接
    char name[m][MAX_LEN];
    for (int i = 0; i < m; ++i) {
        cin >> name[i];
        cou[i].name = name[i];
        cou[i].average = 0;
        cou[i].students = NULL;
    }
    // 排序课程
    sort_course(cou, m);

    // 输入学生基本信息，指针先不连接
    char stu_name[n][MAX_LEN];
    char stu_course[n][MAX_LEN];
    for (int i = 0; i < n; ++i) {
        cin >> stu_name[i];
        stu[i].name = stu_name[i];
        cin >> stu_course[i];
        stu[i].course = NULL;
        cin >> stu[i].grade;
    }
    // 排序学生
    sort_student(stu, n, stu_course);

    // 进行学生->课程的链接
    for (int i = 0; i < n; ++i) {
        stu[i].course = find_course(cou, m, stu_course[i]);
    }

    // 进行课程->学生的链接
    for (int i = 0; i < m; ++i) {
        int stu_num = 0;
        double avg = 0.0;
        for (int j = 0; j < n; ++j) {
            if (stu[j].course == &cou[i]) {
                stu_num++;
                avg += stu[j].grade;
            }
        }

        cou[i].students = (Student *) malloc(stu_num * sizeof(Student));
        int idx = 0;
        for (int j = 0; j < n; ++j) {
            if (stu[j].course == &cou[i]) cou[i].students[idx++] = stu[j];
        }

        cou[i].numStudents = stu_num;
        cou[i].average = avg / stu_num;
    }

    return cou;
} // 实现这个函数
