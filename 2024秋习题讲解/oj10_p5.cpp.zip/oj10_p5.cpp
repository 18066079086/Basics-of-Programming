// 可扩容的动态数组
#include <assert.h>
#include <vector>
#include <algorithm>
#include <iostream>
// #include <malloc.h>
using namespace std;

struct Array {
    int *p;
    int size;
    int capacity;
};

Array *create_array(int value);

void push_back(Array *arr, int value);

void pop(Array *arr);

int get_size(Array *arr);

int get_capacity(Array *arr);

int main() {
    int n;
    cin >> n;
    if (n == 1) {
        Array *arr = create_array(1);
        assert(arr->p[0] == 1);
        assert(get_size(arr) == 1);
    }
    cout << n << endl;
    return 0;
}

Array *create_array(int value) {
    Array *arr = new Array;
    arr->p = new int[1];
    arr->p[0] = value;
    arr->size = 1;
    arr->capacity = 1;
    return arr;
}

void push_back(Array *arr, int value) {
    if (arr->capacity == arr->size) {
        int *new_arr = new int[arr->capacity * 2];
        for (int i = 0; i < arr->capacity; i++) {
            new_arr[i] = arr->p[i];
        }
        arr->capacity *= 2;
        arr->p = new_arr;
    }
    arr->p[arr->size] = value;
    arr->size++;
}

void pop(Array *arr) {
    if (arr->size > 0) {
        arr->size--;
    }
}

int get_size(Array *arr) {
    return arr->size;
}

int get_capacity(Array *arr) {
    return arr->capacity;
}
