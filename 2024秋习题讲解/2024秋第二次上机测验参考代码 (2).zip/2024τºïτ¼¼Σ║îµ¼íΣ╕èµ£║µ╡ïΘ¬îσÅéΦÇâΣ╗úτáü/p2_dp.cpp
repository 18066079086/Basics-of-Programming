#include <iostream>
using namespace std;

int map[21][21] = {0};
int rest[21][21] = {0};

int main() {
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n - i; j++)
            cin >> map[i][j];

    int sum = map[n-1][0];
    if (sum == -1) {
        cout << 0 << endl;
        return 0;
    }

    rest[n-1][0] = map[n-1][0];
    for (int i = n-2; i >= 0; i--) {
        for (int j = 0; j < n - i; j++) {
            // cout << i << ' ' << j << ' ' << map[i][j] << ": " << endl;
            // 特例
            if (map[i][j] == -1) {
                rest[i][j] = -1;
                continue;
            }
            // 处理下方走过来的情况
            int n1 = 0, n2 = 0;
            if ((i + 1 + j < n) && map[i+1][j] != -1) {
                n1 = rest[i+1][j];
            }
            // if (map[i+1][j] > 0) {
            //     n1 = rest[i+1][j];
            // }
            // 处理左边走过来的情况
            if (j - 1 >= 0 && map[i][j - 1] > 0 && map[i][j - 1] % 2 == 1) {
                n2 = rest[i][j-1];
            }
            // cout << n1 << ' ' << n2 << endl;
            if (n1 == 0 && n2 == 0) {
                rest[i][j] = -1;
            } else {
                rest[i][j] = max(n1, n2) + map[i][j];
            }
            if (rest[i][j] > sum) {
                sum = rest[i][j];
            }
        }

    }
    cout << sum;
    return 0;
}
