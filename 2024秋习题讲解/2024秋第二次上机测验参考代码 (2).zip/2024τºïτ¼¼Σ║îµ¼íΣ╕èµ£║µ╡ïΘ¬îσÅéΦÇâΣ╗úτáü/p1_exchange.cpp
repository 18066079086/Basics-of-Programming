#include<iostream>
#include<string>
using namespace std;
const int N = 101;

void bubble(int *score, string *name, int n);

void change_name(string *name, int n, int m);

void sort_cn(string *name, int start, int end);

int main() {
    int n, score[N];
    cin >> n;
    string name[N];
    for (int i = 0; i < n; ++i)
        cin >> name[i] >> score[i];
    bubble(score, name, n);
    for (int i = 0; i < n; ++i) {
        cout << name[i] << " " << score[i] << endl;
    }
    return 0;
}

void bubble(int *score, string *name, int n) {
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n - 1 - i; ++j) {
            if (score[j] < score[j + 1]) {
                int temp1 = score[j];
                score[j] = score[j + 1];
                score[j + 1] = temp1;
                string temp2 = name[j];
                name[j] = name[j + 1];
                name[j + 1] = temp2;
            } else if (score[j] == score[j + 1])
                change_name(name, j, j + 1);
        }
}

void change_name(string *name, int n, int m) {
    int p = name[n].length(), q = name[m].length();
    int minlength = (p < q) ? p : q;
    for (int i = 0; i < minlength; ++i) {
        if ((name[n][i] > name[m][i] && (name[m][i] >= 'a' && name[n][i] <= 'z')) ||
            (name[n][i] > name[m][i] && name[m][i] >= 'A' && name[n][i] <= 'Z') ||
            (name[n][i] < name[m][i] && name[m][i] >= 'a' && name[n][i] <= 'Z')) {
            string temp = name[n];
            name[n] = name[m];
            name[m] = temp;
            return;
        }
        if (name[n][i] != name[m][i])
            return;
    }
    if (p > q) {
        string temp = name[n];
        name[n] = name[m];
        name[m] = temp;
    }
}
