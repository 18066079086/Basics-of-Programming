#include <iostream>
using namespace std;
int a[20][20];
int b[20][20]; //b用来统计走到该位置获得的最大宝藏数量
int n;

void dfs(int x, int y, int sum) {
    b[x][y] = max(b[x][y], sum); //这一步是取之前运算过的，到达b[x][y]的最大的宝藏数
    if (a[x][y] % 2 == 1) {
        //奇数情况
        if (a[x - 1][y] != -1 && x > 0) {
            dfs(x - 1, y, sum + a[x - 1][y]);
        }
        if (a[x][y + 1] != -1 && y + 1 <= n - (x + 1)) {
            dfs(x, y + 1, sum + a[x][y + 1]);
        }
    } else {
        //偶数情况
        if (a[x - 1][y] != -1 && x > 0) {
            dfs(x - 1, y, sum + a[x - 1][y]);
        }
    }
}

int main() {
    cin >> n;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n - i; ++j) {
            cin >> a[i][j];
            b[i][j] = -1;
        }
    }
    dfs(n - 1, 0, a[n - 1][0]);
    int the_max = 0; //初始化宝藏数量是0
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n - i; ++j) {
            the_max = max(b[i][j], the_max); //更新宝藏数量
        }
    }
    cout << the_max;

    return 0;
}
