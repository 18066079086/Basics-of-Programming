#include<iostream>
#include<string>
using namespace std;
const int N = 105;

struct Student {
    string name;
    int grade;
};

int cmpChar(char c1, char c2);

int cmpString(string s1, string s2);

void sortStudent(Student students[], int n);


int main() {
    int n;
    cin >> n;
    Student students[N];
    for (int i = 0; i < n; i++) {
        cin >> students[i].name >> students[i].grade;
    }
    sortStudent(students, n);
    for (int i = 0; i < n; i++) {
        cout << students[i].name << " " << students[i].grade << endl;
    }
    return 0;
}

int cmpChar(char c1, char c2) {
    //在题目要求的顺序下c1<c2，返回1
    if (c1 <= 'Z' && c2 <= 'Z') // 都是大写字母
        return c1 < c2;
    if (c1 >= 'a' && c2 >= 'a') // 都是小写字母
        return c1 < c2;
    if (c1 > c2) // c1小写，c2大写
        return 1;
    return 0;
}

int cmpString(string s1, string s2) {
    //如果s1<s2，返回1
    int min_len = min(s1.length(), s2.length());
    int i = 0;
    for (i = 0; i < min_len; i++) {
        if (s1[i] == s2[i])
            continue;
        return cmpChar(s1[i], s2[i]);
    }
    if (s1.length() < s2.length())
        return 1;
    return 0;
}

void sortStudent(Student students[], int n) {
    for (int i = 0; i < n - 1; ++i)
        for (int j = 0; j < n - 1 - i; ++j)
            if ((students[j].grade < students[j + 1].grade) || (
                    students[j].grade == students[j + 1].grade && !cmpString(students[j].name, students[j + 1].name))) {
                int temp = students[j].grade;
                students[j].grade = students[j + 1].grade;
                students[j + 1].grade = temp;

                string temp1 = students[j].name;
                students[j].name = students[j + 1].name;
                students[j + 1].name = temp1;
            }
}
