#include<iostream>
#include<string>
using namespace std;
const int N = 105;

int cmpChar(char c1, char c2);

int cmpString(string s1, string s2);

void sortStudent(int scores[], string names[], int n);


int main() {
    int n;
    cin >> n;
    int scores[N];
    string names[N];
    for (int i = 0; i < n; i++) {
        cin >>  names[i] >> scores[i];
    }
    sortStudent(scores, names, n);
    for (int i = 0; i < n; i++) {
        cout << names[i] << " " << scores[i] << endl;
    }
    return 0;
}

int cmpChar(char c1, char c2) { //在题目要求的顺序下c1<c2，返回1
    if (c1 <= 'Z' && c2 <= 'Z') // 都是大写字母
        return c1 < c2;
    if (c1 >= 'a' && c2 >= 'a') // 都是小写字母
        return c1 < c2;
    if (c1 > c2) // c1小写，c2大写
        return 1;
    return 0;
}

int cmpString(string s1, string s2) { //如果s1<s2，返回1
    int min_len = min(s1.length(), s2.length());
    int max_len = max(s1.length(), s2.length());
    int i = 0;
    for (i = 0; i < min_len; i++) {
        if (s1[i] == s2[i])
            continue;
        return cmpChar(s1[i], s2[i]);
    }
    if (s1.length() < s2.length())
        return 1;
    return 0;
}

void sortStudent(int scores[], std::string names[], int n) {
    for (int i = 0; i < n - 1; ++i)
        for (int j = 0; j < n - 1 - i; ++j)
            if ((scores[j] < scores[j + 1]) || (scores[j] == scores[j + 1] && !cmpString(names[j], names[j + 1]))) {
                int temp = scores[j];
                scores[j] = scores[j + 1];
                scores[j + 1] = temp;

                string temp1 = names[j];
                names[j] = names[j+1];
                names[j+1] = temp1;
            }
}
