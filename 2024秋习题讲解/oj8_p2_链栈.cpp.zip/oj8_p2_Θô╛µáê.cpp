#include <iostream>
using namespace std;

typedef struct Node Node;

struct Node {
    char data;
    Node* next;
};

void push(Node** head, int data) {
    // cout << "push (" << endl;
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

bool pop(Node** head) {
    // cout << "pop )" << endl;
    if (*head == NULL) return false;
    Node *temp = *head;
    *head = (*head)->next;
    free(temp);
    return true;
}

bool isEmpty(Node* head) {
    if (head == NULL) return true;
    return false;
}

void printList(Node* head) {
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
}


int main() {
    int n;
    cin >> n;

    string str;
    cin >> str;

    Node* head = NULL;

    for (int i = 0; i < str.length(); i++) {
        if (str[i] == '(') {
            push(&head, str[i]);
        } else if (str[i] == ')') {
            if (!pop(&head)) {
                cout << "N\n";
                return 0;
            }
        }
    }
    if (!isEmpty(head)) {
        cout << "N\n";
    } else {
        cout << "Y\n";
    }
    return 0;
}