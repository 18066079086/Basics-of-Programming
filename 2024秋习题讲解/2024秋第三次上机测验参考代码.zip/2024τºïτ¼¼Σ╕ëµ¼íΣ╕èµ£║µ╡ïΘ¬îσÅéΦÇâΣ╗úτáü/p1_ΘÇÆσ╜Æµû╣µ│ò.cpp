#include <iostream>
using namespace std;

int number[50][50];

void change(int x, int y, int m, int n) {
    if (x < 1 || x > m || y < 1 || y > n) return;
    if (number[x + 1][y] == 0) {
        number[x + 1][y] = 1;
        change(x + 1, y, m, n);
    }
    if (number[x - 1][y] == 0) {
        number[x - 1][y] = 1;
        change(x - 1, y, m, n);
    }
    if (number[x][y + 1] == 0) {
        number[x][y + 1] = 1;
        change(x, y + 1, m, n);
    }
    if (number[x][y - 1] == 0) {
        number[x][y - 1] = 1;
        change(x, y - 1, m, n);
    }
}

int main() {
    int n, m;
    cin >> m >> n;

    for (int i = 0; i < 50; ++i) {
        for (int j = 0; j < 50; ++j) {
            number[i][j] = 2;
        }
    }

    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            cin >> number[i][j];
        }
    }

    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (number[i][j] == 1) {
                change(i, j, m, n);
            }
        }
    }

    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (j != n) { cout << number[i][j] << " "; } else { cout << number[i][j]; }
        }
        if (i != m) { cout << endl; }
    }

    return 0;
}