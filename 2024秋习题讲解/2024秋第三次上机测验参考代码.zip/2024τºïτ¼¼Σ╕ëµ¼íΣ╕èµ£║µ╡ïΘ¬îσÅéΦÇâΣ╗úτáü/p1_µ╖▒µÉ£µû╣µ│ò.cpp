#include <iostream>
using namespace std;

const int MAX = 50;
int a[MAX][MAX];
int vis[MAX][MAX];

void dfs(int x, int y, int n, int m) {
    if (x < 0 || x >= n || y < 0 || y >= m) {
        return;
    }

    if (vis[x][y] == 1) {
        return;
    }

    if (a[x][y] == 0) {
        a[x][y] = 1;
    }
    vis[x][y] = 1;

    if (a[x][y] == 2) {
        return;
    }

    dfs(x + 1, y, n, m);
    dfs(x, y + 1, n, m);
    dfs(x - 1, y, n, m);
    dfs(x, y - 1, n, m);
}

int main() {
    int n, m;
    cin >> n >> m;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> a[i][j];
        }
    }
    
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (vis[i][j] == 0 && a[i][j] == 1) {
                dfs(i, j, n, m);
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m - 1; ++j) {
            cout << a[i][j] << ' ';
        }
        cout << a[i][m - 1] << endl;
    }

    return 0;
}
