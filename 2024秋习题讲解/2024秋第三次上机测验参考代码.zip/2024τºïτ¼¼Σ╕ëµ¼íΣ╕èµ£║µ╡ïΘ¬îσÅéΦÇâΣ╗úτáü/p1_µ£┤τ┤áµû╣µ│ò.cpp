#include <iostream>
using namespace std;


int main() {
    int n, m;
    cin >> m >> n;
    int arr[m][n] = {0};
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cin >> arr[i][j];
        }
    }

    for (int i = 0; i < m; i++) {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] == 1) {
                    // 向右蔓延
                    for (int k = i+1; k < m; k++) {
                        if (arr[k][j] == 0) arr[k][j] = 1;
                        else if (arr[k][j] == 2) break;
                    }
                    // 向左蔓延
                    for (int k = i-1; k >= 0; k--) {
                        if (arr[k][j] == 0) arr[k][j] = 1;
                        else if (arr[k][j] == 2) break;
                    }
                    //向下蔓延
                    for (int k = j+1; k < n; k++) {
                        if (arr[i][k] == 0) arr[i][k] = 1;
                        else if (arr[i][k] == 2) break;
                    }
                    //向上蔓延
                    for (int k = j-1; k >= 0; k--) {
                        if (arr[i][k] == 0) arr[i][k] = 1;
                        else if (arr[i][k] == 2) break;
                    }
                }
            }
        }

    }

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n-1; j++) {
            cout << arr[i][j] << " ";
        }
        cout << arr[i][n-1] << endl;
    }

    return 0;
}
