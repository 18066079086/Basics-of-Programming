#include <iostream>
using namespace std;

typedef struct Node Node;

struct Node {
    int data;
    Node* next;
};

void insert(Node** head, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;

    if (*head == NULL) *head = newNode;
    else {
        Node *temp = *head;
        while (temp->next != NULL) temp = temp->next;
        temp->next = newNode;
    }
}

void print(Node* head) {
    while (head->next != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << head->data << endl;
    // cout << head->next->data << endl;
}


Node * merge(Node* head1, Node* head2) {
    Node *p1 = head1, *p2 = head2;
    Node *prev = NULL;
    while (p1 != NULL && p2 != NULL) {
        if (p1->data < p2->data) {
            prev = p1;
            p1 = p1->next;
        } else {
            if (prev != NULL) prev->next = p2;
            else head1 = p2;
            prev = p2;
            p2 = p2->next;
            prev->next = p1;
        }
    }
    if (p2 != NULL) prev->next = p2;
    return head1;
}

void filter(Node** head) {
    if (head == NULL) return;
    if ((*head)-> next == NULL) return;
    Node *cur = (*head)->next;
    Node *prev = *head;
    while (cur != NULL) {
        if (cur->data == prev->data) {
            cur = cur->next;
            prev->next = cur;
        }else {
            prev = cur;
            cur = cur->next;
        }
    }
}


int main() {

    Node *head1 = NULL;
    Node *head2 = NULL;

    int n1;
    cin >> n1;
    for (int i = 0; i < n1; i++) {
        int data;
        cin >> data;
        insert(&head1, data);
    }

    int n2;
    cin >> n2;
    for (int i = 0; i < n2; i++) {
        int data;
        cin >> data;
        insert(&head2, data);
    }

    int n3;
    cin >> n3;

    if (n3 == 0)
        print(head1);
    else if (n3 == 1)
        print(head2);
    else {
        head1 = merge(head1, head2);
        filter(&head1);
        print(head1);
    }

    return 0;
}